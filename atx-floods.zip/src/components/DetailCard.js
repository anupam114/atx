import Card from "react-bootstrap/Card";
import React from "react";

const DetailCard = ({ data, id, setId }) => {
  const [item, setItem] = React.useState(null);
  React.useEffect(() => {
    if (id !== null) {
      setItem(data.data[id]);
      return;
    }
    setItem(null);
  }, [id]);
  if (item) {
    return (
      <Card className="sub-detail">
        <Card.Body className="p-0">
          {/* <Card.Title>Card Title</Card.Title> */}
          <Card.Subtitle className="mb-2 text-muted p-2 py-3">
            <i className="fa-solid fa-arrow-left back_button" onClick={() => setId(null)}></i>
          </Card.Subtitle>
          <div className="text-center p-3 list-item">
            <h6>{item.attributes.name}</h6>
            <p>{item.attributes.address}</p>
            <small className={`status-${item.attributes.state} px-2`}>
              {item.attributes.state}
            </small>
            <small>
              {new Date(item.attributes["updated-at"]).toLocaleString()}
            </small>
          </div>
        </Card.Body>
      </Card>
    );
  }
  return (
    <Card className="sub-detail">
      <Card.Body className="p-0">
        {/* <Card.Title>Card Title</Card.Title> */}
        <Card.Subtitle className="mb-2 text-muted p-2 py-3">
          <span className="status-closed m-2">Closed</span>
          <span className="status-open m-2">Open</span>
          <span className="status-caution m-2">Caution</span>
        </Card.Subtitle>
        {data.data?.map((item, index) => {
          return (
            <div key={index} className="text-center p-3 list-item" onClick={() => setId(index)}>
              <h6>{item.attributes.name}</h6>
              <p>{item.attributes.address}</p>
              <small className={`status-${item.attributes.state} px-2`}>
                {item.attributes.state}
              </small>
              <small>
                {new Date(item.attributes["updated-at"]).toLocaleString()}
              </small>
            </div>
          );
        })}
      </Card.Body>
    </Card>
  );
};

export default DetailCard;
