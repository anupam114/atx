// import { MapContainer } from "react-leaflet/MapContainer";
// import { TileLayer } from "react-leaflet/TileLayer";
// import { useMap } from "react-leaflet/hooks";
import * as L from "leaflet";
import React from "react";
import DetailCard from "./DetailCard";
const ClosoureMap = () => {
  const greenIcon = L.icon({
    iconUrl: "/close_marker.png",
    iconSize: [20, 20], // size of the icon
    iconAnchor: [0, 0], // point of the icon which will correspond to marker's location
  });

  const [closures, setclosures] = React.useState([]);
  const [selectedId, setSelectedId] = React.useState(null);

  React.useEffect(() => {
    (async () => {
      let response = await fetch("http://devh.igiapp.com/AtxApi/closures.json");
      let data = await response.json();
      var map = L.map("map").setView([30.266666, -97.733330], 9);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {}).addTo(
        map
      );

      data.data.forEach((location, index) => {
        L.marker([location.attributes.lat, location.attributes.lng], {
          icon: greenIcon,
        })
          .on("click", () => setSelectedId(index))
          .addTo(map);
      });

      setclosures(data);
    })();
  }, []);
  return (
    <>
      <div id="map"></div>
      <DetailCard data={closures} id={selectedId} setId={setSelectedId}/>
    </>
  );
};

export default ClosoureMap;
