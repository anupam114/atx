import ButtonGroup from 'react-bootstrap/ButtonGroup';
import { Link} from "react-router-dom";

function SubNavigation() {
  return (
    <ButtonGroup aria-label="Basic example" className='sub-nav'>
      <Link className='btn btn-light' to='/crossings'>All Crossings</Link>
      <Link className='btn btn-light' to='/cameras' >Cameras</Link>
      <Link className='btn btn-light' to='/' >Closoures</Link>
    </ButtonGroup>
  )
}

export default SubNavigation;