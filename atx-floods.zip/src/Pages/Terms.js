const Terms = () => {
    return(
        <div>Terms</div>
    );
}

export default Terms;