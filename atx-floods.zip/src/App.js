import './App.css';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Home from './Pages/Home';
import Terms from './Pages/Terms';
import Navigation from './components/Navigation';
import ClosoureMap from './components/ClosureMap';
import CrossingsMap from './components/CrossingsMap';
import CamerasMap from './components/CamerasMap';

function App() {
  return (
    <Router>
      <div className="App">
        <Navigation/>
        <Routes>
          <Route path='/' element={<Home><ClosoureMap/></Home>}/>
          <Route path='/crossings' element={<Home><CrossingsMap/></Home>}/>
          <Route path='/cameras' element={<Home><CamerasMap/></Home>}/>
          <Route path='terms' element={<Terms/>}/>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
